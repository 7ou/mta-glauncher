MTA Grenade Launcher
=============
Features
--------
* Aim with the weapon specified in the script, and press E to fire a grenade. By default, grenades explode on contact and you need to reload between each round you fire.
* Many options such as but not limited to: contact explosion, launch speed, grenade model, weapon lock, team lock; are available for you to modify in the script file. You can find detailed explanations in the script.
* MODIFIED RELOAD RESOURCE IS NO LONGER REQUIRED FOR GLAUNCHER TO RUN.

Todo
--------
* Rewrite class / team / ACL group protection
* Add proper ammo limitation and calculation
* Add ammo etc. display
* Add exports for feature management to replace script configuration

Known Bugs
--------
* The reload management can get bugged when repeatedly triggered. --FIXED
* Grenades may directly explode when launched while travelling at high velocities. --FIXED
